import { useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { LogOut, Users, LayoutGrid, FileText, Building2, Boxes, ShieldCheck, Truck, ScrollText, Settings2, Menu, X, Info } from "lucide-react";
import { useWorkspace } from "@/lib/proc";
import { cn } from "@/lib/utils";
import { useClerk } from "@clerk/react";
import { useAccount } from "@/lib/account";

const demoMode = import.meta.env.VITE_PROCUREMENT_DEMO_MODE === "true";

const NAV = [
  { href: "/dashboard", label: "Overview", icon: LayoutGrid },
  { href: "/requests", label: "Requests", icon: FileText },
  { href: "/approvals", label: "Approvals", icon: ShieldCheck, badge: "approvals" },
  { href: "/orders", label: "Orders", icon: Truck },
  { href: "/suppliers", label: "Suppliers", icon: Building2 },
  { href: "/inventory", label: "Inventory", icon: Boxes, badge: "stock" },
  { href: "/activity", label: "Audit trail", icon: ScrollText },
  { href: "/team", label: "Team", icon: Users, manager: true },
  { href: "/settings", label: "Settings", icon: Settings2, manager: true },
];

export function Layout({ children }: { children: ReactNode }) {
  const [loc] = useLocation();
  const [open, setOpen] = useState(false);
  const { data } = useWorkspace();
  const { account, isManager } = useAccount();
  const { signOut } = useClerk();
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const initials = (account.name || account.email).split(/[\s@.]+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join("");
  const counts: Record<string, number> = { approvals: data?.summary.pendingApprovals ?? 0, stock: data?.summary.lowStock ?? 0 };

  const nav = (
    <nav className="flex flex-col gap-0.5 px-3">
      {NAV.filter((n) => (!("manager" in n) || isManager) && !(demoMode && n.href === "/team")).map((n) => {
        const active = loc.startsWith(n.href);
        const c = n.badge ? counts[n.badge] : 0;
        return (
          <Link key={n.href} href={n.href} onClick={() => setOpen(false)} data-testid={`link-nav-${n.label.toLowerCase().replace(/\s/g, "-")}`}
            className={cn("group relative flex items-center gap-2.5 rounded-md px-2.5 py-2 text-[13px] font-medium transition",
              active ? "bg-white/10 text-white" : "text-sidebar-foreground/70 hover:bg-white/5 hover:text-white")}>
            {active && <span className="absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r bg-sidebar-primary" />}
            <n.icon className={cn("h-4 w-4 transition group-hover:translate-x-0.5", active && "text-sidebar-primary")} />
            {n.label}
            {c > 0 && <span className="num ml-auto rounded bg-sidebar-primary px-1.5 text-[10px] font-semibold text-white">{c}</span>}
          </Link>
        );
      })}
    </nav>
  );

  const brand = (
    <div className="px-5 pb-5 pt-5">
      <div className="flex items-center gap-2.5">
        <div className="grid h-8 w-8 place-items-center rounded-md bg-sidebar-primary text-[11px] font-extrabold text-white">OSP</div>
        <div>
          <div className="text-[11px] font-bold leading-tight text-white">One Stop Smart Procurement</div>
          <div className="truncate text-[11px] text-sidebar-foreground/60">{data?.settings.companyName ?? "Workspace"}</div>
        </div>
      </div>
    </div>
  );

  const foot = (
    <div className="mt-auto space-y-2 p-4 text-[11px] text-sidebar-foreground/60">
      {demoMode && <div className="rounded border border-amber-400/70 bg-amber-950/40 px-2 py-1.5 text-amber-100">Open demo: roles are simulated. Do not enter real or sensitive data.</div>}
      {data?.demoMode && <div className="rounded border border-dashed border-amber-400/60 px-2 py-1.5 text-amber-200">Some suppliers and quotes are sample data.</div>}
      <div className="flex gap-1.5"><Info className="mt-0.5 h-3 w-3 shrink-0" />{demoMode ? "No sign-in required. Demo roles are not a security boundary." : "Signed-in team workspace."} No email or purchasing integrations connected; orders are placed by you outside the system.</div>
      <div className="flex items-center gap-2.5 rounded-md border border-sidebar-border bg-white/5 p-2.5">
        <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-sidebar-primary/20 text-[11px] font-bold text-white ring-1 ring-sidebar-primary/50" data-testid="img-avatar">{initials}</div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[12px] font-semibold text-white" data-testid="text-account-name">{account.name || account.email}</div>
          <div className="flex items-center gap-1.5"><span className={cn("rounded px-1 text-[9px] font-bold uppercase tracking-wider", isManager ? "bg-sidebar-primary text-white" : "bg-white/10 text-sidebar-foreground")} data-testid="text-account-role">{account.role}</span><span className="truncate">{account.email}</span></div>
        </div>
        {demoMode
          ? <Link href="/" title="Switch demo role" className="whitespace-nowrap rounded border border-white/20 px-2 py-1 text-[10px] font-semibold text-white hover:bg-white/10" data-testid="button-switch-demo-role">Switch role</Link>
          : <button type="button" title="Sign out" onClick={() => signOut({ redirectUrl: base || "/" })} className="rounded p-1.5 text-sidebar-foreground/70 transition hover:bg-white/10 hover:text-white" data-testid="button-logout"><LogOut className="h-4 w-4" /></button>}
      </div>
    </div>
  );

  return (
    <div className="min-h-[100dvh] bg-background">
      {demoMode && <div className="sticky top-0 z-40 border-b border-amber-300 bg-amber-50 px-4 py-2 text-center text-xs text-amber-950 md:pl-60"><strong>Demo mode:</strong> Anyone can switch roles. Do not enter real purchasing or personal data.</div>}
      <aside className="fixed inset-y-0 left-0 hidden w-60 flex-col bg-sidebar md:flex">{brand}{nav}{foot}</aside>
      <div className="sticky top-0 z-30 flex items-center justify-between border-b bg-sidebar px-4 py-2.5 md:hidden">
        <span className="text-sm font-bold text-white">One Stop Smart Procurement</span>
        <button onClick={() => setOpen(!open)} className="text-white" data-testid="button-menu">{open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</button>
      </div>
      {open && <div className="fixed inset-0 top-11 z-20 flex flex-col bg-sidebar pt-3 md:hidden">{nav}{foot}</div>}
      <main className="md:pl-60">
        <div className="mx-auto max-w-[1280px] px-4 py-6 md:px-8 md:py-8">{children}</div>
      </main>
    </div>
  );
}
